from flask import Flask


def create_app():
    app = Flask(__name__)

    from board.pages import bp as pages_bp, location_not_found, api_bad_request
    app.register_blueprint(pages_bp)
    app.register_error_handler(400, location_not_found)
    app.register_error_handler(500, api_bad_request)

    return app
